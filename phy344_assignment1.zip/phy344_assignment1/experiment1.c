/*
    Experiment1

    Generate N uniformly distributed random numbers in [-1,1],
    calculate the sample mean and variance,
    and output histogram data using 10 equal-width bins.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Use different bins for different N values*/

int chooseBins(long N)
{
    if (N <= 10)
        return 5;
    else if (N <= 20)
        return 10;
    else if (N <= 50)
        return 10;
    else if (N <= 100)
        return 20;
    else
        return 50;
}

int main(int argc, char *argv[])
{
    /* Read number of samples */

    if (argc != 2)
    {
        printf("Usage: %s <N>\n", argv[0]);
        return 1;
    }

/* Bin dependancy on N*/

    long sampleCount = atol(argv[1]);
    int BINS = chooseBins(sampleCount);

    if (sampleCount <= 0)
    {
        printf("N must be > 0 .\n");
        return 1;
    }

    /* Create an empty array for the sample generated
       Test if array was created successfully 
    */

    double *samples = malloc(sampleCount * sizeof(double));

    if (samples == NULL)
    {
        printf("Memory allocation failed.\n");
        return 1;
    }

    /* Histogram initiation
       Change histogram size dynamically
    */

    int *histogram = calloc(BINS, sizeof(int));
    
    if (histogram == NULL)
    {
        printf("Histogram allocation failed.\n");
        free(samples);
        return 1;
    }

    double sum = 0.0;
    double mean;
    double variance = 0.0;

    srand48(time(NULL));

    /* Random number generation for histogram */

    for (long i = 0; i < sampleCount; i++)
    {
        samples[i] = 2.0 * drand48() - 1.0;

        sum += samples[i];

        int bin = (int)((samples[i] + 1.0) / 2.0 * BINS);

        if (bin >= BINS)
            bin = BINS - 1;

        histogram[bin]++;
    }

    /* Compute the sample mean */

    mean = sum / sampleCount;

    /* Compute the sample variance */

    for (long i = 0; i < sampleCount; i++)
        variance += (samples[i] - mean) * (samples[i] - mean);

    variance /= sampleCount;

    /* Present the results */

    printf("\nExperiment 1 Results\n");
    printf("--------------------\n");
    printf("Samples  : %ld\n", sampleCount);
    printf("Mean     : %.6f\n", mean);
    printf("Variance : %.6f\n", variance);

    /* Save generated histogram */

    FILE *output = fopen("histogram_data.txt", "w");

    if (output == NULL)
    {
        printf("Unable to create output file.\n");
        free(samples);
        return 1;
    }

    double width = 2.0 / BINS;

    fprintf(output, "LowerBound UpperBound Frequency");

    for (int i = 0; i < BINS; i++)
    {
        fprintf(output,
                "%.2f %.2f %d\n",
                -1.0 + i * width,
                -1.0 + (i + 1) * width,
                histogram[i]);
    }

    fclose(output);

    printf("Histogram data written to histogram_data.txt \n");

    free(samples);
    free(histogram);

    return 0;
}
