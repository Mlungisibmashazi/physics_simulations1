% Experiment1 histogram plot for different N values
% Reads histogram data generated from experiment1.c
% Plots the frequency distributions

clear
clc
close all

% Read the histogram data
files = {'histogram_N10.txt', ...
         'histogram_N20.txt', ...
         'histogram_N50.txt', ...        
         'histogram_N100.txt', ...
         'histogram_N1000.txt'};

% Define N
N = [10 20 50 100 1000];

figure

for k = 1:length(files)
    data = readmatrix(files{k}, "NumHeaderLines",1);

    lower = data(:,1);
    upper = data(:,2);
    freq = data(:,3);

    center = (lower + upper)/2;

    subplot(3, 2, k)
    bar(center, freq, 1)

    xlabel("Random Number")
    ylabel("Frequency")
    title(['Histogram of Experiment 1: ' num2str(N(k)) ' Uniform Random Numbers']);
    grid on;
end